﻿using CoreGraphics;
using Foundation;
using System;
using UIKit;

namespace CustomUITextField
{
    public partial class ViewController : UIViewController
    {
        CustomUITextField customUITextField;
        public ViewController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            UITextView uITextView = new UITextView();
            uITextView.Text = "Custom Password UITextfield:";
            uITextView.TextColor = UIColor.Red;
            uITextView.Frame = new CGRect(10, 100, 350, 40);

            customUITextField = new CustomUITextField();
            customUITextField.PasswordChar = '*';
            customUITextField.ShowPasswordDelay = true;
            customUITextField.BackgroundColor = UIColor.LightGray;
            customUITextField.Frame = new CGRect(10, 160, 350, 40);

            View.AddSubview(uITextView);
            View.AddSubview(customUITextField);
            // Perform any additional setup after loading the view, typically from a nib.
        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
            // Release any cached data, images, etc that aren't in use.
        }
    }
}