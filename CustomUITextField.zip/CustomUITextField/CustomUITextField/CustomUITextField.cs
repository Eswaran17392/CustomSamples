﻿using System;
using CoreFoundation;
using Foundation;
using UIKit;

namespace CustomUITextField
{
    public class CustomUITextField : UITextField
    {
        private char passwordChar;
        string data = string.Empty;
        string typedString = string.Empty;
        private string displayString; 
        private bool isBackPressed;
        private bool showPasswordDelay;

        internal string DisplayString
        {
            get
            {
                return this.displayString;
            }
            set
            {
                this.displayString = value;
                this.Text = string.Empty;
                if(ShowPasswordDelay)
                {
                    var popuptTime = new DispatchTime(DispatchTime.Now, 1000000000);

                    DispatchQueue.MainQueue.DispatchAfter(
                    popuptTime,
                    () =>
                    {
                        this.Text = value;
                    });
                }
                else
                {
                    this.Text = value;
                }
            }
        }
        public bool ShowPasswordDelay
        {
            get
            {
                return this.showPasswordDelay;
            }
            set
            {
                this.showPasswordDelay = value;
            }
        }

        public char PasswordChar
        {
            get
            {
                return this.passwordChar;
            }

            set
            {
                this.passwordChar = value;
            }
        }
        public CustomUITextField()
        {
            this.ShouldChangeCharacters += Handle_ShouldChangeCharacters;
        }

        private bool Handle_ShouldChangeCharacters(UITextField textField, NSRange range, string replacementString)
        {
            this.isBackPressed = string.IsNullOrEmpty(replacementString) ? true : false;
            if (isBackPressed)
            {
               typedString = typedString.Remove(typedString.Length - 1);
            }
            else
            {
                typedString += replacementString;
            }

            if (showPasswordDelay)
            {
                ChangeToPasswordChar(textField, typedString);
                return true;
            }
            else
            {
                ChangeToPasswordChar(textField, typedString);
                return false;
            }
        }

        private void ChangeToPasswordChar(UITextField textField, string typedString)
        {
            data = string.Empty;
            for (int i = 0; i < typedString.Length; i++)
            {
                data += this.PasswordChar;
            }
            this.DisplayString = data;
        }
    }
}
