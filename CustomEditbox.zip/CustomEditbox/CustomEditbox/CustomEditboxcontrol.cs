﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace CustomEditbox
{
    class CustomEditboxcontrol : EditText
    {
        private char passwordChar;
        string data = string.Empty;
        string typedString = string.Empty;
        private string displayString;
        private bool isBackPressed;
        private bool showPasswordDelay;
        private Handler handler;

        internal string DisplayString
        {
            get
            {
                return this.displayString;
            }
            set
            {
                this.displayString = value;
                if(ShowPasswordDelay)
                {
                    Java.Lang.Runnable runnable = new Java.Lang.Runnable(() =>
                    {
                        //Console.WriteLine("Delay applied");
                        this.Text = value;
                    });
                    if (handler != null)
                    {
                        handler.RemoveCallbacks(runnable);
                        handler = null;
                    }

                    if (handler == null)
                        handler = new Handler();
                    handler.PostDelayed(runnable, 1000);

                }
                else
                {
                    this.Text = value;
                }
            }
        }
        public bool ShowPasswordDelay
        {
            get
            {
                return this.showPasswordDelay;
            }
            set
            {
                this.showPasswordDelay = value;
            }
        }

        public char PasswordChar
        {
            get
            {
                return this.passwordChar;
            }

            set
            {
                this.passwordChar = value;
            }
        }
        public CustomEditboxcontrol(Context context): base(context)
        {
            this.OnLoading();
        }

        private void OnLoading()
        {
            this.TextChanged += CustomEditboxcontrol_TextChanged;
        }

        private void CustomEditboxcontrol_TextChanged(object sender, Android.Text.TextChangedEventArgs e)
        {
            typedString += e.Text.ToString();
            if (showPasswordDelay)
            {
                ChangeToPasswordChar(typedString);
            }
            else
            {
                ChangeToPasswordChar(typedString);
            }
        }

        private void ChangeToPasswordChar(string typedString)
        {
            data = string.Empty;
            for (int i = 0; i < typedString.Length; i++)
            {
                data += this.PasswordChar;
            }
            this.DisplayString = data;
        }
    }
}