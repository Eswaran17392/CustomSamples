﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Util;

namespace CustomEditbox
{
    class CustomEditboxcontrol : EditText
    {
        private char passwordChar;
        string data = string.Empty;
        string typedString = string.Empty;
        private string displayString;
        private bool isBackPressed;
        private bool showPasswordDelay;
        private Handler handler;
        Timer timer;
        MyTask MyTask;
        internal string DisplayString
        {
            get
            {
                return this.displayString;
            }
            set
            {
                this.displayString = value;
                if(ShowPasswordDelay)
                {
                    if (timer != null)
                    {
                        timer.Cancel();
                        timer.Dispose();
                        timer = null;

                        this.Text = value;
                    }

                    timer = new Timer();
                    MyTask = new MyTask(timer, this, value);
                    timer.Schedule(MyTask, 1000);

                }
                else
                {
                    this.Text = value;
                }
            }
        }
        public bool ShowPasswordDelay
        {
            get
            {
                return this.showPasswordDelay;
            }
            set
            {
                this.showPasswordDelay = value;
            }
        }

        public char PasswordChar
        {
            get
            {
                return this.passwordChar;
            }

            set
            {
                this.passwordChar = value;
            }
        }
        public CustomEditboxcontrol(Context context): base(context)
        {
            this.OnLoading();
        }

        private void OnLoading()
        {
            this.TextChanged += CustomEditboxcontrol_TextChanged;
        }

        private void CustomEditboxcontrol_TextChanged(object sender, Android.Text.TextChangedEventArgs e)
        {
            typedString += e.Text.ToString();
            if (showPasswordDelay)
            {
                ChangeToPasswordChar(typedString);
            }
            else
            {
                ChangeToPasswordChar(typedString);
            }
        }

        private void ChangeToPasswordChar(string typedString)
        {
            data = string.Empty;
            for (int i = 0; i < typedString.Length; i++)
            {
                data += this.PasswordChar;
            }
            this.DisplayString = data;
        }
    }

    internal class MyTask : TimerTask
    {
        private Timer timer;
        private CustomEditboxcontrol Edittext;
        string text;

        public MyTask(Timer timer, CustomEditboxcontrol edittext, string value)
        {
            this.timer = timer;
            Edittext = edittext;
            text = value;
        }

        public override void Run()
        {
            Edittext.Text=text;
        }
    }
}